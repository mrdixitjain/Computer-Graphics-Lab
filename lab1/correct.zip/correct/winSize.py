class size:
	def __init__(self,xmin ,xmax,ymin,ymax):
		self.xmin = xmin
		self.xmax = xmax
		self.ymin = ymin
		self.ymax = ymax